#!/usr/bin/env python
#
import http.server
import socketserver
from hello_module import sayThis

MSG = "Lunch and Learn 2020!"
PORT = 8080


hw = sayThis(MSG)
hw.hello()

Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", PORT), Handler) as httpd:

  text_file = open("index.html", "w")
  n = text_file.write("<br><br><br><center><h1>"+ hw.hello()  +"</h1></center>")
  text_file.close()

  print("serving at port", PORT)
  httpd.serve_forever()
