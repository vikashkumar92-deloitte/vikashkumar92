import unittest2
from hello_module import sayThis

MSG= "Lunch"
hw = sayThis(MSG)

class TestStringMethods(unittest2.TestCase):

  def test_lstrip(self):
    self.assertEqual(hw.hello().lstrip(),'HELLO Lunch')

  def test_isupper(self): #testing for isupper
    self.assertFalse(hw.hello().isupper())

  def test_split(self):
    self.assertEqual(hw.hello().split(),['HELLO','Lunch'])
    with self.assertRaises(TypeError):
      'Hello World'.split(2)

  def test_input(self):
    self.assertIsNot(input, "") 

# Adding some more sample test cases

  def test_output_table(self):
    self.assertEqual(sum([1, 2, 3]), 6, "Should be 6")

if __name__=='__main__':
  unittest2.main()


