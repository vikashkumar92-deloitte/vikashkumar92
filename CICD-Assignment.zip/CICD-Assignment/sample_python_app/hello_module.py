
class sayThis:

  def __init__(self, msg):
    self.msg= msg

  def hello(self):
    return("HELLO " + self.msg)
