#!/bin/bash

URL="https://lunch-learn.main.use1.k8s.mgnt-xspdev.in/api/v1/resources/books/all/JSON"
CURLARGS="--connect-timeout 5 --retry 5"

TEST=$(curl ${CURLARGS} ${URL} | jq '.books[5].author')

if [ "${TEST}" = "null" ]; then 
  echo "No JSON found for [5]" 
  exit 1
else 
  echo "Output discovered. Totally valid test!"
fi

