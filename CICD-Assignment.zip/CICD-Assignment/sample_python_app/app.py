import flask
import json2html
import jinja2
import werkzeug
from flask import request, jsonify, render_template
from json2html import *

app = flask.Flask(__name__)
app.config["DEBUG"] = True



# Create some test data for our catalog in the form of a list of dictionaries.
input = {
    "books": [
        {'id': 0,
        'title': 'A Fire Upon the Deep',
        'author': 'Vernor Vinge',
        'first_sentence': 'The coldsleep itself was dreamless.',
        'year_published': '1992'},
        {'id': 1,
        'title': 'The Ones Who Walk Away From Omelas',
        'author': 'Ursula K. Le Guin',
        'first_sentence': 'With a clamor of bells that set the swallows soaring, the Festival of Summer came to the city Omelas, bright-towered by the sea.',
        'published': '1973'},
        {'id': 2,
        'title': 'The Big Sleep8888',
        'author': 'Raymond Chandler8888',
        'first_sentence': 'Hardboiled crime mystery featuring LA detective Philip Marlowe',
        'published': '1939'},
        {'id': 3,
        'title': 'To Kill A Mockingbird',
        'author': 'Harper Lee',
        'first_sentence': 'Pulitzer Prize-winning novel of race and justice from the view of a child in the Depression-era South.',
        'published': '1960'},
        {'id': 4,
        'title': 'The Great Gatsby',
        'author': 'F. Scott Fitzgerald',
        'first_sentence': 'Jay Gatsby, aka James Gats, struggles to relive the past set against the roaring 1920s.',
        'published': '1925'},
        {'id': 5,
        'title': 'A Separate Peace',
        'author': 'John Knowles',
        'first_sentence': 'A coming-of-age novel during World War 2 set in New Hampshire',
        'published': '1959'}
    ]
}


@app.route('/')
def home():
    return render_template("main.html")


# A route to return all of the available entries in our catalog.
@app.route('/api/v1/resources/books/all/tabular', methods=['GET'])
def api_all_table():
    table_data = json2html.convert(json = input)
    return table_data

@app.route('/api/v1/resources/books/all/JSON', methods=['GET'])
def api_all_json():
    json_data = jsonify(input)
    return json_data

app.run(host='0.0.0.0')
